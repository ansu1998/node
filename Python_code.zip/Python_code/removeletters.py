def removeLetters(str):
    r = 'r'
    count = 0
    for i in str:
        if i == r:
            new_str = str.replace('r','')
            count = count + 1
    print(new_str)
    print(count)


str = "rajeevr"
removeLetters(str)