# Program to find most frequent element in a list

def test(arr):

    max = 0
    res = arr[0]
    for i in arr:
        f = arr.count(i)

        if f > max:
            max = f
            res = i
    print("Most frequent number is : " + str(res))

arr = [1,2,3,4,5,1,4,7,7,5,5]

test(arr)




def most_frequent(List):
    dict = {}
    max = 0
    value = 0
    for i in reversed(List):
        dict[i] = dict.get(i, 0) + 1
        if dict[i] >= max:
            max = dict[i]
            value = i
    print(value)

List = [2, 1, 2, 2, 1, 3]
most_frequent(List)