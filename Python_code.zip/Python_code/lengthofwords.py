def lenghteven(str):
    sp = str.split(" ")
    for i in sp:
        print(len(i))
    str1 = " ".join(sp)
    print(str1)

str = "This is a python language"
lenghteven(str)