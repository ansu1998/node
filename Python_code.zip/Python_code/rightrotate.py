def demo(list1,num):
    n = len(list1)
    list2 = []
    for i in range(n-num,n):
        list2.append(list1[i])

    for i in range(0,n-num):
        list2.append(list1[i])
    print(list2)

list1 = list(map(int, input().split()))
num = 3
demo(list1,num)