def sam(str):
    s = str.replace(" ","")
    print(s)
    st = set(s)
    print(st)

    count = 0
    lst = []
    for i in st:
        for j in str:
            if i == j:
                count+=1
        lst.append({i:count})
        count = 0
    print(lst)

str = "Geeksforgeeks for geeks"
sam(str)