# a =["a","b","c"]
# b = [1,2,3]
# # d={a:1,b:2,c:3}

# d = [{x,y} for x in a for y in b]
# print(d)


# output=[(1,9)(4,6)(7,3)]
# a=[1,4,6,7,3,8,9]
target=10
def demo():
    a=[1,4,6,7,3,8,9]
    n = len(a)
    target = 10
    for i in range(0,n-1):
        for j in range(i+1,n):
            if a[i]+a[j] == target:
                print((a[i],a[j]))

demo()



# a=[10,50,90] 
# b=[20,10,15,30,5,90,70] 
# output=  [5,10,20,30,50,90]

def demo():
    a = [10,50,90]
    b = [20,30,5]
    a.extend(b)
    # a.sort()
    print(a)
    n = len(a)
    for i in range(n-1):
        for j in range(i+1,n):
            if a[i]>a[j]:
                temp = a[i]
                a[i] = a[j]
                a[j] = temp
    print(a)

demo()

def quick_sort(inList):
    if inList == []:
        return []
    else:
        pivot = inList[0]

        lesser = quick_sort([x for x in inList[1:] if x < pivot])
        greater = quick_sort([x for x in inList[1:] if x >= pivot])
        return lesser + [pivot] + greater
    
a = [10,50,90]
b = [20,30,5]
result = quick_sort(list(set(a) | set(b)))
print(result)


# str = "rajeevranjan"

def demo(string):

    s = []
    str = set(string)

    for i in str:
        count = 0
        for j in string:
            if i == j:
                count += 1
        s.append({i:count})

    print(s)

string = "rajeevranjan"
demo(string)


# string = "rajeevranjan"
# demo(string)


#     19=1*1+9*9=82
#     82 is not a single digit so
#     8*8+2*2=68
#     6*6+8*8=100
#     100 is not a single digit
#     1*1+0*0+0*0=1


# def squarenum(num):

#     sum=0
#     temp=num
#     while(temp!=0):
#         r = temp%10
#         sum = sum + r**r
#         temp=temp//10
#     # return sum==num

#     if num==1:
#         print("It is a single digit")

# num = 100
# squarenum(num)