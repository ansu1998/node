x = 1
print(int(x+x))