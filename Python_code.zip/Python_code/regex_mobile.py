import re

# number = input("Enter the mobile number: ")
number = "8660092086"
mobile = "(0|\+91)?[-\s]?[6-9][0-9]{9}"
pattern = re.compile(mobile)

if pattern.match(number):
    print(f"{number} is valid")
else:
    print(f"{number} is not valid")

# num = re.findall(mobile, str)
# print(num)

