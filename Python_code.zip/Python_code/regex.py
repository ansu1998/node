import re

str_email = "ranjanrajeev.apiit@gmail.com"
patt_gmail = r"[0-9a-zA-Z._+%]+@[0-9a-zA-Z._+%]+[.][0-9a-zA-Z.]+"

str_url = """www.google.com, abc"""
patt_url = "http://[a-z0-9_.\-]+\.[a-z0-9_\-/]+"

str_ip = "192.168.01.11"
patt_ip = "[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}"

number = "8660092086"
mobile = "(0|\+91)?[-\s]?[6-9][0-9]{9}"
pattern = re.compile(mobile)

str_card = ["96532526627228"]
patt_card = '^[973][0-9]{15}|[973][0-9]{15}-[0-9]{4}-[0-9]{4}-[0-9]{4}$'

if pattern.match(number):
    print(f"{number} is valid")
else:
    print(f"{number} is not valid")

email = re.findall(patt_ip, str_ip)
print(email)