def password():
    passw = "R@m@_f0rtu9e$"
    n = len(passw)
    l, u, d, s = 0,0,0,0

    if (n>=9):
        for i in passw:
            if (i.islower()):
                l += 1
            if (i.isupper()):
                u += 1           
            if (i.isdigit()):
                d += 1
            # if (i == "@" or i == "_" or i == "$"):
            if (i in ["@", "_", "$"]):
                s += 1
        if (l >= 1 and u >= 1 and d >= 1 and s >= 1 and l + u + d + s == n):
            print("Valid Password")
        else:
            print("Invalid Password")

password()

            