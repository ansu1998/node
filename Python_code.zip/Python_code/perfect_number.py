def perfectnumber(n):
    # 6 = 1 + + 2 + 3  Perfect number
    r = []
    sum = 0
    for i in range(1,n):
        if n%i==0:
            r.append(i)
            sum += i
    print(sum)
    print(r)
    if n == sum:
        print("This is Perfect number")
    else:
        print("This is not perfect number")

n = int(input())
perfectnumber(n)