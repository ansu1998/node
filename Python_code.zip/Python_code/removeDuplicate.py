def removeDuplicate(str):
	s=set(str)
	s="".join(s)
	print("Without Order:",s)
	t=""
	for i in str:
		if(i in t):
			pass
		else:
			t=t+i
		print("With Order:",t)
	
str="geeksforgeeks"
removeDuplicate(str)

def test(num):
    n = len(num)
    d = []
    for i in range(n-1):
        for j in range(i+1,n):
            if num[i] == num[j]:
                d.append(num[i])
            else:
                pass

    print(d)

num = [1,1,2,3,4,5,6,7,8,8,9,10]
test(num)
