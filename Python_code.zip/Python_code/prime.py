def primeno():
    
    start =1
    end = 19
    lst = []
    for n in range(start, end+1):
        if n>1:
            for i in range(2,int(n/2)+1):
                if(n % i==0):
                    break
            else:
                # print(n, end=" ")
                lst.append(n)
    print(lst)
primeno()
