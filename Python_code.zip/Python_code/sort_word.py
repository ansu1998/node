def sortWords(str):
    strlist = str.split(" ")
    print(strlist)
    list = []
    rev = []

    for i in strlist:
        strlist = i.lower()
        list.append(strlist)
    print(list)

    for i in range(len(list)-1,-1,-1):

        for j in range(i):
            if list[j] > list[j + 1]:
                list[j], list[j + 1] = list[j + 1], list[j]
    print("Sorted words are: ", list)

str = "python Java rajeev abc"
sortWords(str)