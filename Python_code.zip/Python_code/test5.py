def greet(a, b,c=2):
    sum=a+b+c

    print(sum)


greet(5,6)