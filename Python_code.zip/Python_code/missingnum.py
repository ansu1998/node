# def test(num):
#     n = len(num)
#     total = (n+1) * (n+2)/2
#     sum = sum(num)
#     m = total - sum

# num = [1,2,3,5]
# test(num)

def demo():
    n = int(input())
    num = list(map(int, input().split()))
    sum = 0
    total = 0
    for i in range(1,n+1):
        sum += i
    print(sum)
    for i in range(n-1):
        total += i
    x = sum - total
    print(x)
    print(total)

demo()


def solve(nums):

    arr = [0]*(len(nums)+1)
    print(arr)
    for i in nums:
        arr[i] += 1
    missing = []
    for i in range(len(arr)):
        if arr[i] == 0 and i != 0:
            missing.append(i)
        
    print(missing)

nums = [4,4,2,2,6,6]
solve(nums)
