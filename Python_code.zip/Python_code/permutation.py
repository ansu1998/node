# Print all Permutations of given String:

def permute(str, start, end):
    if start == end:
        str1 = ' '.join(str)
        print(str1)
    else:
        for i in range(start, end):
            str[start], str[i] = str[i], str[start]
            permute(str, start+1, n)
            str[start], str[i] = str[i], str[start]

string = "ABC"
n = len(string)
str = list(string)
permute(str, 0, n)
