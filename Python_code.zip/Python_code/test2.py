# list = [[20],[50],[70],[40]]
# new_list = [set(x) for x in list]
# print(new_list)

l1=['red','green','blue']
l2 = [0,1,2]
new_list = [[a,b] for a,b in zip(l1,l2)]
new_list = [(a,b) for a,b in zip(l1,l2)]
# new_list = [(a,b) for a in l1 for b in l2]
print(new_list)