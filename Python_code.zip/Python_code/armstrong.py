def isArmstrong(num):

    n = len(str(num))
    temp = num
    t = 0
    while(temp!=0):
        r = temp%10
        t = t + r**n
        temp = temp//10
    print(t)
    print(num)

    if t==num:
        print("It is armsstrong")
    else:
        print("Not a Armstrong")

num = int(input())
isArmstrong(num)

