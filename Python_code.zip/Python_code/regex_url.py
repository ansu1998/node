import re

str_link = """http://google.com, abc"""

url1 = "http://[a-z0-9_.\-]+\.[a-z0-9_\-/]+"

url3 = "(https?://|www\.)?(www\.)?([a-z0-9]+)(\..)?"
link = re.findall(url1, str_link)

print(link)