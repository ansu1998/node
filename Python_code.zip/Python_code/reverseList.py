# def demo():
    
#     list1 = list(map(int, input().split()))
#     list2 = []
#     n = len(list1)
#     start = 0
#     last = n-1

#     while(last>=0):
#         list2.append(list1[last])
#         start += 1
#         last -= 1

#     for i in range(n):
#         print(list2[i], end=" ")

    
# demo()

############################################################################

def demo():
    
    list1 = list(map(int, input().split()))
    list2 = []
    n = len(list1)
    for i in range(n,0,-1):
        list2.append(i)
    print(list2)

demo()

##############################################################################

def test(arr):
    # print(arr[::-1])
    n = len(arr)
    print(arr[n::-1])

arr = [1,2,3,4,5,6,7,8,9,10]
test(arr)

#############################################################

def test(arr):
    l = []
    for i in arr:
        l.insert(0,i)
    print(l)

arr = [1,2,3,4,5,6,7,8,9,10]
test(arr)
