def palindrome(str):
    n = len(str)
    rev = ""
    for i in range(n-1,-1,-1):
        rev = rev + str[i]
    print(rev)

    if str == rev:
        print("Palindrome")
    else:
        print("Not Palindrome")

str = "malayalam"
palindrome(str)
