def sam(str):
    s = str.split(" ")
    word = ["best", "CS", "for"]
    rep = "gfg"
    r1 = []
    r2 = []
    # res = ' '.join([rep if i in word else i for i in s])
    # print(res)
    for i in s:
        if i in word:
            r1.append(rep)
        else:
            r1.append(i)
    a = '  '.join(r1)
    print(r1)
    print(a)      
        
str = "Geeksforgeeks is best for geeks and CS"
sam(str)