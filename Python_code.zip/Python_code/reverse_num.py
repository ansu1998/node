rev = 0
num = 2123400
while num!=0:
    a = num%10
    rev = rev*10 + a
    num = num//10

print(rev)