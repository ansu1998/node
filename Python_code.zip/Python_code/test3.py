i = 0

while(i<45):
    if (i+1<5):
        print(i)
        i= i+1
        
        continue #return to the while loop statement.

    print(i+1, end=" ")
    if i==44:
        break #stop the loop
    i = i+1