# Python program to validate an Ip address

import re

def check(Ip):

	regex = r"[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}"
    
	if(re.match(regex, Ip)):
		print("Valid Ip address")
		
	else:
		print("Invalid Ip address")
	
Ip = "192.168.01.11"
check(Ip)
