def fizzbuzz(n):
    for i in range(n):
        if i % 3 == 0 and i % 5 == 0:
            print("fizzbuzz")
            continue
        if i % 3 == 0:
            print("fizz")
            continue
        if i % 5 == 0:
            print("buzz")
            continue

n = 11
fizzbuzz(n)
