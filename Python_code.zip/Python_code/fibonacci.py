
def fibonacci(n):
    x = 0
    y = 1
    c = 0

    for i in range(1,n+1):
        c = x + y
        print(c, end=" ")
        x = y
        y = c

fibonacci(10)


# temp = a
# a = b
# b = temp

