# We can modify tuple inside list.append.
# We can't list inside the tuple. It will give the Type error.

lst1 = [("hi", 1), ("there", 2), ("jane", 3)]
lst1 = [(2,7), (3,5), (4,8)]
lst2 = [45, 67, 21]

result = [(i[0], i[1], j) for i, j in zip(lst1, lst2)]

print(result)