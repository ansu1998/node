def factorial(n):
    if n<0:
        return 0

    elif n==0 and n==1:
        return 1

    else:
        fac = 1
        for i in range(1,n+1):
            fac=fac*i

        return fac

n=9
x = factorial(n)
print(x)
        