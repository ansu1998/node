def lenghteven(str1, str2):
    sp1 = str1.split(" ")
    sp2 = str2.split(" ")
    rev = []
    for i in sp1:
        if i not in sp2:
            rev.append(i)
    for i in sp2:
        if i not in sp1:
            rev.append(i)
    a = list(set(rev))
    print(a)

a = "Geeks for Geeks"
b = "Learning from Geeks for Geeks"
lenghteven(a,b)