import random

my_list= [x for x in range(1,101)]
random_number = random.choice(my_list)
emp_list = []

if random_number%3!=0 and random_number%5!=0:
    if random_number%3==0:

        emp_list.append(random_number)

    elif random_number%5 ==0:
        emp_list.append(random_number)

    else:
        print("Number is not divisible")





# create 2 numbers a=10,b=5
# create list f1 it contain all factors of a=10
# create list f2 it contain all factors of b=10
# create a list comm =[] it contain common numbers list f1 and f2
# return biggest element from comm

def factor_no(a,b,n):
    

    list1 = [i for i in range(1,n) if a%i==0]
    list2 = [i for i in range(1,n) if b%i==0]
    comm = [(i, y) for i in list1 for y in list2 if i==y]
    


factor_no(10,10,100)

# print(emp_list)
