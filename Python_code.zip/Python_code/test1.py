for i in range(10):
    if i % 3 == 0 and i % 5 == 0:
        print("fizzbuzz")
        continue
    elif i % 3 == 0:
        print("fizz")
        continue
    elif i % 5 == 0:
        print("buzz")
        continue
    print(i)
	

# class Solution(object):
#    def fizzBuzz(self, n):
#       """
#       :type n: int
#       :rtype: List[str]
#       """
#       result = []
#       for i in range(1,n+1):
#          if i% 3== 0 and i%5==0:
#             result.append("FizzBuzz")
#          elif i %3==0:
#             result.append("Fizz")
#          elif i% 5 == 0:
#             result.append("Buzz")
#          else:
#             result.append(str(i))
#       return result
# ob1 = Solution()
# print(ob1.fizzBuzz(30))