import re

str = "ranjanrajeev.apiit@gmail.com"

patt = r"[0-9a-zA-Z._+%]+@[0-9a-zA-Z._+%]+[.][0-9a-zA-Z.]+"
email = re.findall(patt, str)

print(email)