# z=set('abc')
# z.add('san')
# z.update(set(['p', 'q']))
# print(z)


# s1={3, 4}
# s2={1, 2}
# s3=set()
# i=0
# j=0
# for i in s1:
#     for j in s2:
#         s3.add((i,j))
#         i+=1
#         j+=1
# print(s3)


# a = [5,5,6,7,7,7]
# b = set(a)
# def test(lst):
#     if lst in b:
#         return 1
#     else:
#         return 0
# for i in  filter(test, a):
#     print(i,end=" ")


# def sum(*args):
#    '''Function returns the sum 
#    of all values'''
#    r = 0
#    for i in args:
#       r += i
#    return r


# print (sum.__doc__)
# print (sum(1, 2, 3))
# print (sum(1, 2, 3, 4, 5))


# def power(x, y=2):
#     r = 1
#     for i in range(y):
#        r = r * x
#     return r
# print (power(3))
# print (power(3, 3))


# count={}
# count[(1,2,4)] = 5
# count[(4,2,1)] = 7
# count[(1,2)] = 6
# count[(4,2,1)] = 2
# tot = 0
# for i in count:
#     tot=tot+count[i]
# print(len(count)+tot)


# def addItem(listParam):
#     listParam += [1]
 
# mylist = [1, 2, 3, 4]
# addItem(mylist)
# print(len(mylist))


# i = 0
# while i < 5:
#     print(i)
#     i += 1
#     if i == 3:
#         break
# else:
#     print(0)


# list1 = [1,2,3,4]
# list2 = [2,4,5,6]
# list3 = [2,6,7,8]
# result = list()
# result.extend(i for i in list1 if i not in (list2+list3) and i not in result)
# result.extend(i for i in list2 if i not in (list1+list3) and i not in result)


# z=set('abc')
# z.add('san')
# z.update(set(['p', 'q']))
# print(z)


# def foo(x):
#     x[0] = ['def']
#     x[1] = ['abc']
#     return id(x)
# q = ['abc', 'def']
# print(id(q) == foo(q))


# class tester:
#     def __init__(self, id):
#         self.id = str(id)
#         id="224"


# temp = tester(12)
# print(temp.id)


# for i in [1, 2, 3, 4][::-1]:
#     print (i)


# def f(value, values):
#     v = 1
#     values[0] = 44
# t = 3
# v = [1, 2, 3]
# f(t, v)
# print(t, v[0])


# i = 0
# while i < 3: 
#     print (i) 
#     i += 1
# else: 
#     print (0)

# def myfunc(a):
#     a = a + 2
#         a = a * 2
#     return a

# print myfunc(2)



